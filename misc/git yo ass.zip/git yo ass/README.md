# misc/git yo ass

I just took over someone's git repository, but it seems that some important files were being reset'd forcefully

Plz help me recover them

(If you somehow messed up the git, just unzip the BACKUP on the same directory as this folder)

Flag format: TaoCTF{[a-zA-Z0-9_]}

Hint:\
git restore, git log